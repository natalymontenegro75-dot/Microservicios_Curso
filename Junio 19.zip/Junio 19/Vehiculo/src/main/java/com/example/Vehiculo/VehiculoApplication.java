package com.example.Vehiculo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehiculoApplication {

	public static void main(String[] args) {

		IAdminVehiculo Crud = new CrudVehiculo();

		Crud.agregarVehiculo(new AutoElectrico(
				"JHG234", "Tesla", "2026", "Blanco",5, 0, "Disponible",
				400, 80, 2,4, 4));

		Crud.agregarVehiculo(new MotoElectrica(
				"LKJ876", "Tesla", "2025", "Negro",	2, 0, "Disponible",
				100, 70, 3,"Scooter", "Eléctrico"));

		Crud.agregarVehiculo(new AutoCombustible(
				"POR569", "Toyota", "2024", "Rojo", 5, 2800, "Disponible",
				"Deasel", 12, 45, 4, 4));

		Crud.agregarVehiculo(new MotoCombustible(
				"ALK056", "Yamaha", "2023", "Azul", 2, 150, "Disponible",
				"Corriente", 3, 90,	"Deportiva", "Eléctrico"));


		Crud.buscarPorPasajeros(1);
		Crud.buscarConsumoPorPlaca("ALK056");
		Crud.obtenerVehiculos();
	}

}
