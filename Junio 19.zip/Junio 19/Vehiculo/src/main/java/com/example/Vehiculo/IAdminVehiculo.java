package com.example.Vehiculo;

public interface IAdminVehiculo {
    void agregarVehiculo(Vehiculo v);
    void obtenerVehiculos();
    boolean actualizarEstado(String placa, String nuevoEstado);
    void buscarConsumoPorPlaca(String placa);
    void buscarPorPasajeros(int cantidad);
}
