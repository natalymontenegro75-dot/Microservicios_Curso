package com.example.Vehiculo;

import java.util.ArrayList;
import java.util.List;

public class CrudVehiculo implements IAdminVehiculo{
    private List<Vehiculo> vehiculos = new ArrayList<>();

    public CrudVehiculo() {
        this.vehiculos = new ArrayList<>();
    }

    //Insertar
    @Override
    public void agregarVehiculo(Vehiculo v) {
        this.vehiculos.add(v);
    }

    //Modificar el Estado de un Vehiculo
    @Override
    public boolean actualizarEstado(String placa, String nuevoEstado) {
        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                v.setEstado(nuevoEstado);
                return true; // se modificó correctamente
            }
        }
        return false; // no se encontró el vehículo
    }

    //ConsultarTodo
    @Override
    public void obtenerVehiculos() {
        System.out.println("----------------Los Vehiculos en Registro son:-------------------");
        for (Vehiculo v : vehiculos) {
                System.out.println("Marca: " + v.getMarca());
                System.out.println("Modelo: " + v.getModelo());
                System.out.println("Cilindraje: " +v.getCilindraje());
                System.out.println("Pasajeros: " + v.getCantidadPasajeros());
                System.out.println("Placa: " + v.getModelo());
                System.out.println("Estado: " +v.getEstado());
                System.out.println("---------------------------------------------");

        }
    }

    //Buscar por pasajeros
    @Override
    public void buscarPorPasajeros(int cantidad) {
        System.out.println("Vehiculos Disponibles para "+ cantidad +" o mas Pasajeros: ");
        for (Vehiculo v : vehiculos) {
            if (v.getCantidadPasajeros() >= cantidad && v.getEstado().equalsIgnoreCase("Disponible")) {
                System.out.println("Vehículo encontrado:");
                System.out.println("Marca: " + v.getMarca());
                System.out.println("Modelo: " + v.getModelo());
                System.out.println("Pasajeros: " + v.getCantidadPasajeros());
                System.out.println("Placa: " + v.getModelo());
                System.out.println("---------------------------------------------");
            }
        }
    }

    //Devolver el consumo por placa
    @Override
    public void buscarConsumoPorPlaca(String placa) {
        System.out.println("El consumo en pesos por Km para el vehiculo de placa "+ placa +" es: ");
        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                System.out.println(v.obtenerConsumo());
            }
        }
    }

}
