package com.example.Vehiculo;

public class VehiculoCombustible extends Vehiculo {
    private String tipoCombustible;
    private double capacidadTanque;
    private double kmPorGalon;
    //Constructor
    public VehiculoCombustible(String placa, String marca, String modelo,
                             String color,int cantidadPasajeros,
                             double cilindraje,String estado, String tipoCombustible,
                             double capacidadTanque, double kmPorGalon){
        super(placa,marca,modelo,color,cantidadPasajeros,cilindraje,estado);
        this.tipoCombustible = tipoCombustible;
        this.capacidadTanque = capacidadTanque;
        this.kmPorGalon = kmPorGalon;
    }

    public String getTipoCombustible() {
        return tipoCombustible;
    }

    public double getCapacidadTanque() {
        return capacidadTanque;
    }

    public double getKmPorGalon() {
        return kmPorGalon;
    }

    public void setTipoCombustible(String tipoCombustible) {
        this.tipoCombustible = tipoCombustible;
    }

    public void setCapacidadTanque(double capacidadTanque) {
        this.capacidadTanque = capacidadTanque;
    }

    public void setKmPorGalon(double kmPorGalon) {
        this.kmPorGalon = kmPorGalon;
    }

    //Retorno Valor en pesos por Km
    @Override
    public double obtenerConsumo() {
        if (getTipoCombustible().equalsIgnoreCase("Corriente")){
            return (16000 / getKmPorGalon());
        }else{
            return (12000 / getKmPorGalon());
        }
    }

}
