package com.example.Flota.Controler;

import com.example.Flota.Client.CotizadorClient;
import com.example.Flota.Client.VehiculoClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/flotas")
public class FlotaController {

    @Autowired
    private CotizadorClient cotizadorClient;

    @Autowired
    private VehiculoClient vehiculoClient;

    @GetMapping("/mas-economico")
    public String cotizarMejorViaje(@RequestParam double km) {

        // 1. Llama al microservicio de Vehículos
        //var vehiculos = VehiculoClient.obtenerVehiculos();

        // 2. Llama al microservicio Cotizador
        double costo = cotizadorClient.cotizarCosto(km);

        return "El auto gana con costo " + costo;
    }
}