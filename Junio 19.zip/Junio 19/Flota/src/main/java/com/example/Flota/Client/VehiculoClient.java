package com.example.Flota.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "Vehiculo")
public interface VehiculoClient {

    @GetMapping("/api/vehiculo")
    static void obtenerVehiculos();

}