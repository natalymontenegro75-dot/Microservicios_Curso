package com.example.Flota.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "Cotizador")
public interface CotizadorClient {

    @GetMapping("/api/cotizador")
    double cotizarCosto(
            @RequestParam double km
    );
}