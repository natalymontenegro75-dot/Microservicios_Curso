package com.example.Flota;
import java.util.Scanner;

public class Menus {

    public static void  MenuListar() {
        Scanner sc = new Scanner(System.in);
        int opcMenu;
        int numeroPasajeros;
        System.out.println("=========== MENÚ FLOTA=============");
        System.out.println("1. Imprimir Todos los Vehículos");
        System.out.println("2. Imprimir Los Vehiculos por Numero de Pasajeros");
        System.out.print("Seleccione una opción: ");
        opcMenu = sc.nextInt();
        switch (opcMenu) {
            case 1:
                System.out.println("Conectar con Consulta Crud.obtenerVehiculos()");
                Menus.CotizarReserva();
                break;
            case 2:
                System.out.println("Indique la Cantidad de Pasajeros Deseada: ");
                numeroPasajeros = sc.nextInt();
                System.out.println("Conectar con Crud.buscarPorPasajeros(numeroPasajeros);");
                Menus.CotizarReserva();
                break;
            default:
                System.out.println("Opción no válida");
                sc.close();
        }
    }

    public static void CotizarReserva() {
        Scanner sc = new Scanner(System.in);
        String Placa;
        float distancia;
        String tipoViaje;
        int tiempoHoras;
        String opcMenu;
        String reservar;

        System.out.println("=========== COTIZAR RESERVA =============");
        System.out.print("Del Listado Consultado indique la Placa a Cotizar: ");
        Placa = sc.nextLine();
        System.out.print("Indique la Distancia en Km que va a recorrer: ");
        distancia = sc.nextFloat();
        System.out.print("Indique el Tiempo  en Horas que va a Ocupar el Vehiculo, Recuerde que en Caso de Exceder el Tiempo Debera Pagar un Recargo por Hora Adicional: ");
        tiempoHoras=sc.nextInt();
        System.out.println("Indique su Tipo de Viaje: ");
        System.out.println("1. Municipal");
        System.out.println("2. InterMunicipal");
        opcMenu = sc.next();
        switch (opcMenu) {
            case "1":
                tipoViaje= "Municipal";
                break;
            case "2":
                tipoViaje= "Intermunicipal";
                break;
            default:
                System.out.println("Opción no válida");
        }
        System.out.println("Conectar con Calculo.cotizarCosto(Placa, distancia,tipoViaje, tiempoHoras)");
        System.out.println("Indique si Desea Hacer la Reserva (S, N): ");
        reservar = sc.next();
        switch (reservar) {
            case "S":
                System.out.println("Conectar con actualizarEstado");
                break;
            case "N":
                MenuListar();
                break;
            default:
                System.out.println("Opción no válida");
        }

        sc.close();
    }

}
