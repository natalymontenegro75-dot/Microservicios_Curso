package com.example.Flota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class FlotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlotaApplication.class, args);
	}
}
