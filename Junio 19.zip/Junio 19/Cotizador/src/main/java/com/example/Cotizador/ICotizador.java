package com.example.Cotizador;

public interface ICotizador {

    double cotizarCosto(String placa, float distancia, String tipoViaje, int tiempoHoras);

}