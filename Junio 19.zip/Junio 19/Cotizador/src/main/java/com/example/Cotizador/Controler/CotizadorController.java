package com.example.Cotizador.Controler;

import com.example.Cotizador.Calcular;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cotizador")
public class CotizadorController {

    private final Calcular calcular;

    public CotizadorController(Calcular calcular) {
        this.calcular = calcular;
    }

    @GetMapping
    public double cotizarCosto(
            @RequestParam double km) {

        return calcular.cotizarCosto("ABC123", (float) km, "Municipal", 2);
    }
}