package com.example.Cotizador;

import org.springframework.stereotype.Service;

@Service
public class Calcular implements ICotizador{
    @Override
    public double cotizarCosto(String placa, float distancia, String tipoViaje, int tiempoHoras){

        double costoFijoServicio = 15000;
        double costoFijoTiempo = 2000;
        double factorTipoViaje;

        double costoKm = 177.77;

        if (tipoViaje.equals("Municipal")){
            factorTipoViaje = 1.2;
        } else {
            factorTipoViaje = 1.4;
        }

        double costeTiempoViaje = tiempoHoras * costoFijoTiempo;
        double costeCombustibleViaje = distancia * costoKm;

        return ((costeTiempoViaje + costoFijoServicio) * factorTipoViaje)
                + costeCombustibleViaje;
    }
}