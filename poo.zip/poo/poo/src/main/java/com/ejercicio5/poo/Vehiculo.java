package com.ejercicio5.poo;

public abstract class Vehiculo {
    private String placa;
    private String marca;
    private String modelo;
    private String color;
    private int cantidadPasajeros;
    private double cilindraje;
    private String estado;

//Constructor
    public Vehiculo(String placa, String marca, String modelo,
                    String color,int cantidadPasajeros,
                    double cilindraje,String estado) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.color=color;
        this.cantidadPasajeros = cantidadPasajeros;
        this.cilindraje = cilindraje;
        this.estado = estado;
    }

    public abstract double calcularCostoViaje(double distanciaViaje);

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public int getCantidadPasajeros() {
        return cantidadPasajeros;
    }

    public double getCilindraje() {
        return cilindraje;
    }

    public String getEstado() {
        return estado;
    }
}