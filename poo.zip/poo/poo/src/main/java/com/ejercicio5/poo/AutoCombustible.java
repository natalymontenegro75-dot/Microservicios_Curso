package com.ejercicio5.poo;

class AutoCombustible extends VehiculoCombustible {
    private int cantidadPuertas;
    private int cantidadRuedas;

    public AutoCombustible(String placa, String marca, String modelo, String color,
                           int cantidadPasajeros, double cilindraje, String estado,
                           String tipoCombustible, double capacidadTanque, double kmPorGalon,
                           int cantidadPuertas, int cantidadRuedas) {

        super(placa, marca, modelo, color, cantidadPasajeros, cilindraje,
                estado, tipoCombustible, capacidadTanque, kmPorGalon);
        this.cantidadPuertas = cantidadPuertas;
        this.cantidadRuedas = cantidadRuedas;
    }

    @Override
    public double calcularCostoViaje(double distancia) {
        double precioGalon = 16400;
        return (distancia / getKmPorGalon()) * precioGalon;
    }
}
