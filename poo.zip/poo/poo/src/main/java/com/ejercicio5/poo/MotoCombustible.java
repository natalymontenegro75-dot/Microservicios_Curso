package com.ejercicio5.poo;

class MotoCombustible extends VehiculoCombustible {
    private String tipoMoto;
    private String tipoArranque;
    public MotoCombustible(String placa, String marca, String modelo, String color,
                           int cantidadPasajeros, double cilindraje, String estado,
                           String tipoCombustible, double capacidadTanque, double kmPorGalon,
                           String tipoMoto, String tipoArranque) {

        super(placa, marca, modelo, color, cantidadPasajeros, cilindraje,
                estado, tipoCombustible, capacidadTanque, kmPorGalon);
        this.tipoMoto = tipoMoto;
        this.tipoArranque = tipoArranque;
    }

    @Override
    public double calcularCostoViaje(double distancia) {
        double precioGalon = 15000;
        return (distancia / getKmPorGalon()) * precioGalon;
    }
}
