package com.ejercicio5.poo;

public abstract class VehiculoElectrico extends Vehiculo {
    private double autonomia;
    private double porcentajeBateria;
    private double tiempoCarga;
    //Constructor
    public VehiculoElectrico(String placa, String marca, String modelo,
                             String color,int cantidadPasajeros,
                             double cilindraje,String estado, double autonomia,
                             double porcentajeBateria, double tiempoCarga){
        super(placa,marca,modelo,color,cantidadPasajeros,cilindraje,estado);
        this.autonomia = autonomia;
        this.porcentajeBateria = porcentajeBateria;
        this.tiempoCarga = tiempoCarga;
    }

    public double getPorcentajeBateria() {
        return porcentajeBateria;
    }

    public double getTiempoCarga() {
        return tiempoCarga;
    }

    public double getAutonomia() {
        return autonomia;
    }
    public abstract double calcularCostoViaje(double distanciaViaje);
}
