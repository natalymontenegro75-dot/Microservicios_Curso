package com.ejercicio5.poo;

import java.util.ArrayList;
import java.util.List;

public class Flota {
    private String nombre;
    private List<Vehiculo> vehiculos = new ArrayList<>();

    public Flota(String nombre) {
        this.nombre = nombre;
        this.vehiculos = new ArrayList<>();
    }

    public void agregarVehiculo(Vehiculo v) {
        vehiculos.add(v);
    }

    // Polimorfismo
    public void calcularCostos(double distancia) {
        for (Vehiculo v : vehiculos) {
            System.out.println(v.calcularCostoViaje(distancia));
        }
    }

    public void buscarPorPasajerosYCalcular(int cantidad, double distancia) {
        for (Vehiculo v : vehiculos) {
            if (v.getCantidadPasajeros() >= cantidad) {
                System.out.println("Vehículo encontrado:");
                System.out.println("Marca: " + v.getMarca());
                System.out.println("Modelo: " + v.getModelo());
                System.out.println("Pasajeros: " + v.getCantidadPasajeros());

                double costo = v.calcularCostoViaje(distancia);
                System.out.println("Costo del viaje: " + costo);
                System.out.println("----------------------------");
            }
        }
    }

}