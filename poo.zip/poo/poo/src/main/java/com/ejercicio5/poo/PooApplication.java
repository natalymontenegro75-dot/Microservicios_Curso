package com.ejercicio5.poo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooApplication {

	public static void main(String[] args) {

		Flota flota = new Flota("MiFlota");

		flota.agregarVehiculo(new AutoElectrico(
				"JHG234", "Tesla", "2026", "Blanco",5, 0, "Disponible",
				400, 80, 2,4, 4));

		flota.agregarVehiculo(new MotoElectrica(
				"LKJ876", "Tesla", "2025", "Negro",	2, 0, "Disponible",
				100, 70, 3,"Scooter", "Eléctrico"));

		flota.agregarVehiculo(new AutoCombustible(
				"POR569", "Toyota", "2024", "Rojo", 5, 2800, "Disponible",
				"Deasel", 12, 45, 4, 4));

		flota.agregarVehiculo(new MotoCombustible(
				"ALK056", "Yamaha", "2023", "Azul", 2, 150, "Disponible",
				"Corriente", 3, 90,	"Deportiva", "Eléctrico"));
		//Buscar vehículos con 5 pasajeros y calcular costo
		flota.buscarPorPasajerosYCalcular(5, 100);
	}

}
