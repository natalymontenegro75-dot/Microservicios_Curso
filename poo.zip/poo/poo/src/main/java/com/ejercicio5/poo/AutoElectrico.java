package com.ejercicio5.poo;

public class AutoElectrico extends VehiculoElectrico {
    private int cantidadPuertas;
    private int cantidadRuedas;

    public AutoElectrico(String placa, String marca, String modelo, String color,
                         int cantidadPasajeros, double cilindraje, String estado,
                         double autonomia, double porcentajeBateria, double tiempoCarga,
                         int cantidadPuertas, int cantidadRuedas) {

        super(placa, marca, modelo, color, cantidadPasajeros, cilindraje,
                estado, autonomia, porcentajeBateria, tiempoCarga);
        this.cantidadPuertas = cantidadPuertas;
        this.cantidadRuedas = cantidadRuedas;
    }

    @Override
    public double calcularCostoViaje(double distancia) {
        double costoCarga = 30000;
        return (distancia / getAutonomia()) * costoCarga;
    }
}
