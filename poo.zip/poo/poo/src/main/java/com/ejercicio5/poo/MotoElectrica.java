package com.ejercicio5.poo;

class MotoElectrica extends VehiculoElectrico {
    private String tipoMoto;
    private String tipoArranque;

    public MotoElectrica(String placa, String marca, String modelo, String color,
                         int cantidadPasajeros, double cilindraje, String estado,
                         double autonomia, double porcentajeBateria, double tiempoCarga,
                         String tipoMoto, String tipoArranque) {

        super(placa, marca, modelo, color, cantidadPasajeros, cilindraje,
                estado, autonomia, porcentajeBateria, tiempoCarga);

        this.tipoMoto = tipoMoto;
        this.tipoArranque = tipoArranque;
    }

    @Override
    public double calcularCostoViaje(double distancia) {
        double costoCarga = 80000;
        return (distancia / getAutonomia()) * costoCarga;
    }
}
