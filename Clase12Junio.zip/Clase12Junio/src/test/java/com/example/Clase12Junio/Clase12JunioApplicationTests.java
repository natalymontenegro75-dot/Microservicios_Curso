package com.example.Clase12Junio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase12JunioApplicationTests {

	@Test
	void contextLoads() {
	}

}
