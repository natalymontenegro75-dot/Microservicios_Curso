package com.example.Clase12Junio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase12JunioApplication {

	public static void main(String[] args) {
		System.out.println("Iniciando....");
		Biblioteca biblioteca = new Biblioteca("BibliotecaUno");

		biblioteca.agregar(new LibroElectronico(
				"El mundo de Pepito", "Juan Pérez", 2015, "PDF", 5.5,
				200, true));

		biblioteca.agregar(new LibroElectronico(
				"Los compas y el diamantito", "Ana Gómez", 2018, "ePub", 3.2,
				150, false));

		biblioteca.agregar(new LibroElectronico(
				"El caballero de la armadura Oxidada", "Robert Fisher", 2008, "PDF", 6.8,
				300, true));

		// Mostrar todos los libros
		System.out.println("-----LISTAR TODOS LOS LIBROS-------");
		biblioteca.mostrarRecursos();

		// Buscar el más antiguo
		System.out.println("-----BUSQUEDA DEL MAS ANTIGUO-------");
		biblioteca.recursoMasAntiguo();

	}
}
