package com.example.Clase12Junio;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private String nombre;
    private List<RecursoBibliografico> libros;

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        libros = new ArrayList<>();
    }

    public void agregar(RecursoBibliografico r) {
        libros.add(r);
    }

    // Mostrar todos los libros que tiene la biblioteca
    public void mostrarRecursos() {
        for (RecursoBibliografico r : libros) {
            System.out.println(r.obtenerResumen());
        }
    }

    // Buscar el más antiguo por año
    public void recursoMasAntiguo() {
        RecursoBibliografico masAntiguo = libros.get(0);

        for (RecursoBibliografico r : libros) {
            if (r.getAnioPublicacion() < masAntiguo.getAnioPublicacion()) {
                masAntiguo = r;
            }
        }
        System.out.println("El libro más antiguo de la biblioteca "+this.nombre+" es:");
        System.out.println(masAntiguo.obtenerResumen());
    }
}
