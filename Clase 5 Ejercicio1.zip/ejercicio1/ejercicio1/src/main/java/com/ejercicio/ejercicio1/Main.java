package com.ejercicio.ejercicio1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Main {
	public Main(){
}
	public static void main(String[] args) {
		System.out.println(x: "Ejercicio 1: Factura con Polimorfismo y Serialización\n");
		Producto laptop = new Producto(nombre: "Laptop",(double) 1200.00F, cantidad:2);
		Producto teclado = new Producto(nombre: "Teclado",(double) 1500.00F, cantidad:4);
		Producto monitor = new Producto(nombre: "Monitor",(double) 5200.00F, cantidad:2);
		Producto soporte = new Producto(nombre: "Soporte técnico",(double) 300.00F, horas trabajadas:5);

		Factura factura = new Factura(numeroFactura: "F001",cliente: "Juan Perez");
		factura.agregarItem(laptop);
		factura.agregarItem(teclado);
		factura.agregarItem(minitor);
		factura.agregarItem(soporte);
		factura.agregarItem(desarrollo);
		factura.imprimirFactura();
		factura.serializarItems();
		Pagable [] elementos = new pagable[]{laptop,teclado,monitor,soporte,desarrollo};
		Pagable [] elementos = new Pagable[]{laptop,teclado,monitor,soporte,desarrollo};


		for (Pagable elemento : elementos) {
			System.out.println("\nDescripción: " + elemento.descripcion());
			System.out.println("Pago a realizar: $" + elemento.calcularPago());
		}

		SpringApplication.run(Ejercicio1Application.class, args);
	}

}
