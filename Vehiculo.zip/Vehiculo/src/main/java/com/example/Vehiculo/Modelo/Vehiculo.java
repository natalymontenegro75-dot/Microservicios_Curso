package com.example.Vehiculo.Modelo;

public abstract class Vehiculo {
    private String placa;
    private String marca;
    private String modelo;
    private String color;
    private int cantidadPasajeros;
    private double cilindraje;
    private String estado;
//Estados Disponible, Ocupado, Eliminado
//Constructor
    public Vehiculo(String placa, String marca, String modelo,
                    String color,int cantidadPasajeros,
                    double cilindraje,String estado) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.color=color;
        this.cantidadPasajeros = cantidadPasajeros;
        this.cilindraje = cilindraje;
        this.estado = estado;
    }
    public Vehiculo() {
    }

    public String getPlaca() {
        return placa;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public int getCantidadPasajeros() {
        return cantidadPasajeros;
    }

    public double getCilindraje() {
        return cilindraje;
    }

    public String getEstado() {
        return estado;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setCantidadPasajeros(int cantidadPasajeros) {
        this.cantidadPasajeros = cantidadPasajeros;
    }

    public void setCilindraje(double cilindraje) {
        this.cilindraje = cilindraje;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public abstract double obtenerConsumo();
}