package com.example.Vehiculo.Service;

import com.example.Vehiculo.Modelo.Vehiculo;
import java.util.List;

public interface IAdminVehiculo {
    void agregarVehiculo(Vehiculo v);
    List<Vehiculo> obtenerVehiculos();
    boolean actualizarEstado(String placa, String nuevoEstado);
    double buscarConsumoPorPlaca(String placa);
    List<Vehiculo> buscarPorPasajeros(int cantidad);
}
