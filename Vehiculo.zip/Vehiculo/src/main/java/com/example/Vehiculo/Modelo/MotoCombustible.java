package com.example.Vehiculo.Modelo;

public class MotoCombustible extends VehiculoCombustible {
    private String tipoMoto;
    private String tipoArranque;
    public MotoCombustible(String placa, String marca, String modelo, String color,
                           int cantidadPasajeros, double cilindraje, String estado,
                           String tipoCombustible, double capacidadTanque, double kmPorGalon,
                           String tipoMoto, String tipoArranque) {

        super(placa, marca, modelo, color, cantidadPasajeros, cilindraje,
                estado, tipoCombustible, capacidadTanque, kmPorGalon);
        this.tipoMoto = tipoMoto;
        this.tipoArranque = tipoArranque;
    }
    public MotoCombustible(){}
    public String getTipoMoto() {
        return tipoMoto;
    }

    public void setTipoMoto(String tipoMoto) {
        this.tipoMoto = tipoMoto;
    }

    public String getTipoArranque() {
        return tipoArranque;
    }

    public void setTipoArranque(String tipoArranque) {
        this.tipoArranque = tipoArranque;
    }

}
