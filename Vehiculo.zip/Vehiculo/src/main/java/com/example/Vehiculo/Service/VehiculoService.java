package com.example.Vehiculo.Service;

import com.example.Vehiculo.Modelo.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class VehiculoService  implements IAdminVehiculo {
    private List<Vehiculo> vehiculos = new ArrayList<>();

    public VehiculoService () {
        this.vehiculos = new ArrayList<>();
        // ==========================
        // AUTOS A COMBUSTIBLE DATOS INICIALES DE PRUEBA
        // ==========================

        vehiculos.add(new AutoCombustible(
                "ABC123",
                "Toyota",
                "Corolla",
                "Blanco",
                5,
                1800,
                "Disponible",
                "Corriente",
                14,
                45,
                4,
                4));

        vehiculos.add(new AutoCombustible(
                "DEF456",
                "Mazda",
                "CX-5",
                "Gris",
                5,
                2500,
                "Disponible",
                "Corriente",
                15,
                42,
                4,
                4));

        vehiculos.add(new AutoCombustible(
                "GHI789",
                "Chevrolet",
                "Captiva",
                "Negro",
                7,
                3000,
                "Ocupado",
                "Diesel",
                18,
                38,
                4,
                4));

        // ==========================
        // MOTOS A COMBUSTIBLE
        // ==========================

        vehiculos.add(new MotoCombustible(
                "JKL111",
                "Yamaha",
                "FZ 2.0",
                "Azul",
                2,
                150,
                "Disponible",
                "Corriente",
                3.5,
                95,
                "Deportiva",
                "Eléctrico"));

        vehiculos.add(new MotoCombustible(
                "MNO222",
                "Honda",
                "XR190",
                "Rojo",
                2,
                190,
                "Disponible",
                "Corriente",
                3.2,
                90,
                "Enduro",
                "Pedal"));

        // ==========================
        // AUTOS ELÉCTRICOS
        // ==========================

        vehiculos.add(new AutoElectrico(
                "TES001",
                "Tesla",
                "Model 3",
                "Blanco",
                5,
                0,
                "Disponible",
                500,
                95,
                1.5,
                4,
                4));

        vehiculos.add(new AutoElectrico(
                "BYD002",
                "BYD",
                "Han",
                "Azul",
                5,
                0,
                "Disponible",
                610,
                80,
                2,
                4,
                4));

        vehiculos.add(new AutoElectrico(
                "KIA003",
                "Kia",
                "EV6",
                "Gris",
                5,
                0,
                "Ocupado",
                520,
                65,
                2.5,
                4,
                4));

        // ==========================
        // MOTOS ELÉCTRICAS
        // ==========================

        vehiculos.add(new MotoElectrica(
                "ELE101",
                "Super Soco",
                "TC Max",
                "Negro",
                2,
                0,
                "Disponible",
                120,
                90,
                4,
                "Scooter",
                "Eléctrico"));

        vehiculos.add(new MotoElectrica(
                "ELE202",
                "NIU",
                "NQi GT",
                "Blanco",
                2,
                0,
                "Disponible",
                110,
                85,
                3.5,
                "Scooter",
                "Eléctrico"));
    }

    //Insertar
    @Override
    public void agregarVehiculo(Vehiculo v) {
        this.vehiculos.add(v);
    }

    //Modificar el Estado de un Vehiculo
    @Override
    public boolean actualizarEstado(String placa, String nuevoEstado) {
        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                v.setEstado(nuevoEstado);
                return true; // se modificó correctamente
            }
        }
        return false; // no se encontró el vehículo
    }

    //ConsultarTodo
    @Override
    public List<Vehiculo> obtenerVehiculos()  {
            return vehiculos;
    }

    //Buscar por pasajeros
    @Override
    public List<Vehiculo> buscarPorPasajeros(int cantidad) {
        List<Vehiculo> vehiculosPasajeros=new ArrayList<>();
        for (Vehiculo v : vehiculos) {
            if (v.getCantidadPasajeros() >= cantidad && v.getEstado().equalsIgnoreCase("Disponible")) {
                vehiculosPasajeros.add(v);
            }
        }
        return vehiculosPasajeros;
    }

    //Devolver el consumo por placa
    @Override
    public double buscarConsumoPorPlaca(String placa) {
        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                return v.obtenerConsumo();
            }
        }
        return -1;
    }


}
