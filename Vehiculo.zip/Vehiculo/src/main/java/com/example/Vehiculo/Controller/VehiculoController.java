package com.example.Vehiculo.Controller;

import com.example.Vehiculo.Modelo.Vehiculo;
import com.example.Vehiculo.Service.VehiculoService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController                           //Esta clase atenderá peticiones HTTP
@RequestMapping("/vehiculos")          //Indica todas las url inician con http://localhost:8081/vehiculos
public class VehiculoController {
    private final VehiculoService service;

    public VehiculoController(VehiculoService service) {   //Constructor
        this.service = service;
    }

    @GetMapping
    public List<Vehiculo> obtenerVehiculos() {
        return service.obtenerVehiculos();
    }

    @GetMapping("/pasajeros/{cantidad}")
    public List<Vehiculo> buscarPorPasajeros(
            @PathVariable int cantidad){
        return service.buscarPorPasajeros(cantidad);
    }

    @GetMapping("/consumo/{placa}")
    public double consumo(@PathVariable String placa){
        return service.buscarConsumoPorPlaca(placa);
    }

    @PutMapping("/{placa}/estado")
    public boolean actualizarEstado(
            @PathVariable String placa,
            @RequestParam String estado){
        return service.actualizarEstado(placa,estado);
    }
}
