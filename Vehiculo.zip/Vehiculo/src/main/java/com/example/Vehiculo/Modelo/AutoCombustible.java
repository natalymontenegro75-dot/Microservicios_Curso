package com.example.Vehiculo.Modelo;

public class AutoCombustible extends VehiculoCombustible {
    private int cantidadPuertas;
    private int cantidadRuedas;

    public AutoCombustible(String placa, String marca, String modelo, String color,
                           int cantidadPasajeros, double cilindraje, String estado,
                           String tipoCombustible, double capacidadTanque, double kmPorGalon,
                           int cantidadPuertas, int cantidadRuedas) {

        super(placa, marca, modelo, color, cantidadPasajeros, cilindraje,
                estado, tipoCombustible, capacidadTanque, kmPorGalon);
        this.cantidadPuertas = cantidadPuertas;
        this.cantidadRuedas = cantidadRuedas;
    }
    public AutoCombustible(){}

    public int getCantidadPuertas() {
        return cantidadPuertas;
    }

    public void setCantidadPuertas(int cantidadPuertas) {
        this.cantidadPuertas = cantidadPuertas;
    }

    public int getCantidadRuedas() {
        return cantidadRuedas;
    }

    public void setCantidadRuedas(int cantidadRuedas) {
        this.cantidadRuedas = cantidadRuedas;
    }

}
