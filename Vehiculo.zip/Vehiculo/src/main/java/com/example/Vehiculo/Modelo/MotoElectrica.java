package com.example.Vehiculo.Modelo;

public class MotoElectrica extends VehiculoElectrico {
    private String tipoMoto;
    private String tipoArranque;

    public MotoElectrica(String placa, String marca, String modelo, String color,
                         int cantidadPasajeros, double cilindraje, String estado,
                         double autonomia, double porcentajeBateria, double tiempoCarga,
                         String tipoMoto, String tipoArranque) {

        super(placa, marca, modelo, color, cantidadPasajeros, cilindraje,
                estado, autonomia, porcentajeBateria, tiempoCarga);

        this.tipoMoto = tipoMoto;
        this.tipoArranque = tipoArranque;
    }
    public MotoElectrica(){}
    public String getTipoMoto() {
        return tipoMoto;
    }

    public void setTipoMoto(String tipoMoto) {
        this.tipoMoto = tipoMoto;
    }

    public String getTipoArranque() {
        return tipoArranque;
    }

    public void setTipoArranque(String tipoArranque) {
        this.tipoArranque = tipoArranque;
    }

}
