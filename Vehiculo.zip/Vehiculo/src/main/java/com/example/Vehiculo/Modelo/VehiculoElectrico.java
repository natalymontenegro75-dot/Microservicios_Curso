package com.example.Vehiculo.Modelo;

public abstract class VehiculoElectrico extends Vehiculo {
    private double autonomia;
    private double porcentajeBateria;
    private double tiempoCarga;
    //Constructor
    public VehiculoElectrico(String placa, String marca, String modelo,
                             String color,int cantidadPasajeros,
                             double cilindraje,String estado, double autonomia,
                             double porcentajeBateria, double tiempoCarga){
        super(placa,marca,modelo,color,cantidadPasajeros,cilindraje,estado);
        this.autonomia = autonomia;
        this.porcentajeBateria = porcentajeBateria;
        this.tiempoCarga = tiempoCarga;
    }
    public VehiculoElectrico() {
    }
    public double getPorcentajeBateria() {
        return porcentajeBateria;
    }

    public double getTiempoCarga() {
        return tiempoCarga;
    }

    public double getAutonomia() {
        return autonomia;
    }

    public void setAutonomia(double autonomia) {
        this.autonomia = autonomia;
    }

    public void setPorcentajeBateria(double porcentajeBateria) {
        this.porcentajeBateria = porcentajeBateria;
    }

    public void setTiempoCarga(double tiempoCarga) {
        this.tiempoCarga = tiempoCarga;
    }

    @Override
    public double obtenerConsumo() {
        return (53000/getAutonomia());
    }

}
