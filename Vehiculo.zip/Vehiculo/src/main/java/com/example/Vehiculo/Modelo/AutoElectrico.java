package com.example.Vehiculo.Modelo;

public class AutoElectrico extends VehiculoElectrico {
    private int cantidadPuertas;
    private int cantidadRuedas;

    public AutoElectrico(String placa, String marca, String modelo, String color,
                         int cantidadPasajeros, double cilindraje, String estado,
                         double autonomia, double porcentajeBateria, double tiempoCarga,
                         int cantidadPuertas, int cantidadRuedas) {

        super(placa, marca, modelo, color, cantidadPasajeros, cilindraje,
                estado, autonomia, porcentajeBateria, tiempoCarga);
        this.cantidadPuertas = cantidadPuertas;
        this.cantidadRuedas = cantidadRuedas;
    }
    public AutoElectrico(){}
    public int getCantidadPuertas() {
        return cantidadPuertas;
    }

    public void setCantidadPuertas(int cantidadPuertas) {
        this.cantidadPuertas = cantidadPuertas;
    }

    public int getCantidadRuedas() {
        return cantidadRuedas;
    }

    public void setCantidadRuedas(int cantidadRuedas) {
        this.cantidadRuedas = cantidadRuedas;
    }

}
