package com.ejercicio.ejercicio1;

public interface Serializable {
    String serializar();
}