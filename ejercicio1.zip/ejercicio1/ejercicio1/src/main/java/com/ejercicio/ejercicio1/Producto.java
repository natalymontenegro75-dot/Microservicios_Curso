package com.ejercicio.ejercicio1;
public class Producto implements Pagable,Serializable{
    private String nombre;
    private double precio;
    private int cantidad;

    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public double calculaTotal(){
        return this.precio*(double) this.cantidad;
    }
    public double aplicarDescuento(double porcentaje){
        double total= calculaTotal();
        return total-(total*porcentaje/100);
    }
    public String descripcion(){
        return String.format(format:"Producto: %s | precio $%.2f |Cantidad %d |Total con Descuento:$%.2f",
                this.nombre,
                this.precio,
                this.cantidad,
                this.aplicarDescuento(porcentaje:10));

    }
    public String getNombre() {
        return this.nombre;
    }
    public double getPrecio() {
        return this.precio;
    }

    public int getCantidad() {
        return this.cantidad;
    }

    public String toString(){
        return this.descripcion();
    }
}