package com.example.Flota.Client;

import com.example.Flota.Controler.DTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "vehiculo-service")
public interface VehiculoClient {

    @GetMapping("/vehiculos")
    List<DTO> obtenerVehiculos();

    @GetMapping("/vehiculos/pasajeros/{cantidad}")
    List<DTO> buscarPorPasajeros(
            @PathVariable int cantidad);

    @GetMapping("/vehiculos/consumo/{placa}")
    double buscarConsumo(
            @PathVariable String placa);
}