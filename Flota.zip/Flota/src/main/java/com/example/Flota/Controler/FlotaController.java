package com.example.Flota.Controler;

import com.example.Flota.Client.CotizadorClient;
import com.example.Flota.Client.VehiculoClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/flotas")
public class FlotaController {

    @Autowired
    private CotizadorClient cotizadorClient;

    @Autowired
    private VehiculoClient vehiculoClient;

    @GetMapping("/vehiculos")
    public Object listarVehiculos() {
        return vehiculoClient.obtenerVehiculos();
    }
    @GetMapping("/vehiculos/pasajeros/{cantidad}")
    public List<DTO> buscarPorPasajeros(@PathVariable int cantidad) {
        return vehiculoClient.buscarPorPasajeros(cantidad);
    }
    @GetMapping("/vehiculos/consumo/{placa}")
    public double consumo(@PathVariable String placa){
        return vehiculoClient.buscarConsumo(placa);
    }
    @GetMapping("/cotizar")
    public double cotizar(
            @RequestParam String placa,
            @RequestParam double distancia,
            @RequestParam String tipoViaje,
            @RequestParam int tiempoHoras){
        double consumo = vehiculoClient.buscarConsumo(placa);
        return cotizadorClient.cotizarCosto(
                consumo,
                distancia,
                tipoViaje,
                tiempoHoras);
    }
}