package com.example.Cotizador.Controler;

import com.example.Cotizador.Service.Calcular;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/cotizador")
public class CotizadorController {

    private final Calcular calcular;

    public CotizadorController(Calcular calcular) {
        this.calcular = calcular;
    }

    @GetMapping
    public double cotizarCosto(
            @RequestParam double costoKm,
            @RequestParam double distancia,
            @RequestParam String tipoViaje,
            @RequestParam int tiempoHoras) {

        return calcular.cotizarCosto(costoKm,distancia,tipoViaje,tiempoHoras);
    }
}