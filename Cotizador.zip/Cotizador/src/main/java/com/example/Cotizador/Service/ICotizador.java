package com.example.Cotizador.Service;

public interface ICotizador {

    double cotizarCosto(double costoKm, double distancia, String tipoViaje, int tiempoHoras);

}