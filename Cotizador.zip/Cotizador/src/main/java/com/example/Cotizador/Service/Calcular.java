package com.example.Cotizador.Service;

import org.springframework.stereotype.Service;

@Service
public class Calcular implements ICotizador {

    @Override
    public double cotizarCosto(double costoKm, double distancia, String tipoViaje, int tiempoHoras){

        double costoFijoServicio = 15000;
        double costoFijoTiempo = 2000;
        double factorTipoViaje;


        if (tipoViaje.equalsIgnoreCase("Municipal")){
            factorTipoViaje = 1.2;
        } else {
            factorTipoViaje = 1.4;
        }

        double costeTiempoViaje = tiempoHoras * costoFijoTiempo;
        double costeCombustibleViaje = distancia * costoKm;

        return ((costeTiempoViaje + costoFijoServicio) * factorTipoViaje)
                + costeCombustibleViaje;
    }
}